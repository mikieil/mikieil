$('#search-icon').click(function(){
    $('.box').addClass('open')
});
$('.srch-cls').click(function(){
    $('.box').removeClass('open')
});
const ctaclose = document.getElementById('cta-cls');
const menuup = document.getElementById('main-nav');
const main_page = document.getElementById('home-page');

ctaclose.onclick = function(){
    ctaclose.classList.toggle('hide')
    menuup.classList.toggle('hide')
}

$('.space-mobile-menu-icon').on('click', function(){
'use strict';
    $('.space-mobile-menu').addClass('active');
});

$('.menu-close').on('click', function(){
'use strict';
    $('.space-mobile-menu').removeClass('active');
});


